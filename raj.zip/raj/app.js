const express = require ("express");
const app = express();
const mongoose = require("mongoose")
const ejs = require("ejs");
const _ = require("lodash");

const bodyParser = require("body-parser");
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb://localhost:27017/Roadmap", {useNewUrlParser: true});

const postSchema = {
  title: String,
  content: String
};

const Roadmap = mongoose.model("Roadmap", postSchema);


// this route is only responsible for rendering the home page
app.get("/" ,function(req,res){
    res.sendFile(__dirname + "/index.html");
    
})

// route responsible for rendering composed blogs

app.get("/Blogs", function(req, res){

    Roadmap.find({}, function(err, Roadmaps){
       
      res.render("Blogs", {
        posts: Roadmaps
        
        });

    });
  });

// app.get("/posts/:postName", function (req, res) {
//     const requestedtitle = _.lowerCase(req.params.postName)

//     Posts.forEach(function (post) {
//         const storedtitle = _.lowerCase(post.title);

//         if (storedtitle === requestedtitle) {
//             res.render("post", {
//                 title: post.title,
//                 content: post.content
//             })
//         }
//     });
// })

app.get("/posts/:postId", function(req, res){

    const requestedPostId = req.params.postId;
    
      Roadmap.findOne({_id: requestedPostId}, function(err, post){
        res.render("post", {
          title: post.title,
          content: post.content
        });
      });
    
    });


app.get("/Home" ,function(req,res){
    res.render("Home", {posts : Posts })
})




app.get("/compose", function(req,res){
    res.render("Compose");
})

// this post method will create and render the new blog on blogs page

app.post("/compose", function(req, res){
    console.log(req.body.postTitle)
    const scheme = new Roadmap({
      title: req.body.postTitle,
      content: req.body.postBody
    });
  
  
    scheme.save(function(err){
      if (!err){
          res.redirect("/Blogs");
      }
    });
  });

  const userSchema = {
    name : String,
    number: Number,
    email: String
  };
  
  const DList = mongoose.model("DList", userSchema);

  
app.post("/signup", function(req, res){
    


  const user = new DList({
      name: req.body.userName,
      number: req.body.cNumber,
      email:req.body.cEmail
    });
  
  
    user.save(function(err){
      if (!err){
          res.redirect("/");
      }
    });




});
app.get("/signup", function (req, res) {
  res.render("signup");
})

// route to render the user list or reader list 
app.get("/userlist", function(req, res){

  DList.find({}, function(err, DLists){
      
    res.render("Users", {
      posts: DLists
      
      });

  });
}); 

app.get("/about", function(req,res){
    res.render("about");
})

app.get("/schemes", function(req,res){
    res.render("schemes");
})

app.listen(3000, function(){
    console.log("server satrted on port number 3000")
})